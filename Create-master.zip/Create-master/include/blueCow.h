#ifndef BLUE_COW_H
#define BLUE_COW_H

void blueCow();

#endif
