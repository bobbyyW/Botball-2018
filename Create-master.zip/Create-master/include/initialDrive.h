#ifndef INITIAL_DRIVE_H
#define INITIAL_DRIVE_H
/**
 * Initial drive task, starts at base and grabs first haybale
 * and squares off at first good point
 */

// TODO start this stuff
void initialDrive();

#endif
