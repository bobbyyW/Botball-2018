#ifndef FARM_HAY_BALES_H
#define FARM_HAY_BALES_H

void farmHayBales();

#endif
