# Code for create

## Steps to transfer code

If you dont have my ecmin program installed, type `sudo npm install -g ecmin`

If you don't already have a file called out/main.c in your directory, open terminal and change directory to the create root directory then execute the following commands:
```
mkdir out
cd out
touch main.c
cd ..
```

#### To transfer:
1. Open your command line
2. Change directory the the root create folder
3. Execute the command `ecmin`
4. Wait for it to complete, and then copy everything from out/main.c into the kipr IDE
5. You are done :)
6. Please note that we moved the kipr project to botball-create
